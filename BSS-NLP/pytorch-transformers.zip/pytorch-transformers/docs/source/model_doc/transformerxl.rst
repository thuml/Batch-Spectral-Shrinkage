Transformer XL
----------------------------------------------------


``TransfoXLConfig``
~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: pytorch_transformers.TransfoXLConfig
    :members:


``TransfoXLTokenizer``
~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: pytorch_transformers.TransfoXLTokenizer
    :members:


``TransfoXLModel``
~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: pytorch_transformers.TransfoXLModel
    :members:


``TransfoXLLMHeadModel``
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: pytorch_transformers.TransfoXLLMHeadModel
    :members:
